#!/bin/bash
ncat -e ./run2.sh -l 9999
