var localizedStrings = new Array;

localizedStrings['Edit'] = 'Wijzig';
localizedStrings['Done'] = 'Gereed';
localizedStrings['Theme:'] = 'Thema:';
localizedStrings['Glass'] = 'Glas';
localizedStrings['Black Edge'] = 'Zwarte rand';
localizedStrings['Deckled Edge'] = 'Kartelige rand';
localizedStrings['Pegboard'] = 'Gaatjesboard';
localizedStrings['Torn Edge'] = 'Gerafelde rand';
localizedStrings['Vintage Corners'] = 'Klassieke hoeken';
localizedStrings['Only play audio in Dashboard'] = 'Speel audio alleen af in Dashboard';
