var localizedStrings = new Array;

localizedStrings['Edit'] = 'Править';
localizedStrings['Done'] = 'Готово';
localizedStrings['Theme:'] = 'Тема:';
localizedStrings['Glass'] = 'Стекло';
localizedStrings['Black Edge'] = 'Черный край';
localizedStrings['Deckled Edge'] = 'Обрезанный край';
localizedStrings['Pegboard'] = 'Программная панель';
localizedStrings['Torn Edge'] = 'Рваный край';
localizedStrings['Vintage Corners'] = 'Винтажные углы';
localizedStrings['Only play audio in Dashboard'] = 'В Dashboard - только аудио';
