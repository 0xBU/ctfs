var localizedStrings = new Array;

localizedStrings['Edit'] = 'Composizione';
localizedStrings['Done'] = 'Fine';
localizedStrings['Theme:'] = 'Tema:';
localizedStrings['Glass'] = 'Vetro';
localizedStrings['Black Edge'] = 'Lato nero';
localizedStrings['Deckled Edge'] = 'Lato con smerlo';
localizedStrings['Pegboard'] = 'Pannello perforato';
localizedStrings['Torn Edge'] = 'Lato strappato';
localizedStrings['Vintage Corners'] = 'Angoli vintage';
localizedStrings['Only play audio in Dashboard'] = 'Esegui audio in Dashboard';
