var localizedStrings = new Array;

localizedStrings['Edit'] = '편집';
localizedStrings['Done'] = '완료';
localizedStrings['Theme:'] = '테마:';
localizedStrings['Glass'] = '유리 효과';
localizedStrings['Black Edge'] = '검은 가장자리';
localizedStrings['Deckled Edge'] = '종이 가장자리';
localizedStrings['Pegboard'] = '페그보드';
localizedStrings['Torn Edge'] = '찢긴 가장자리';
localizedStrings['Vintage Corners'] = '빈티지 모서리';
localizedStrings['Only play audio in Dashboard'] = 'Dashboard가 보일 때만 오디오 재생';
