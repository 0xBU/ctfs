var localizedStrings = new Array;

localizedStrings['Edit'] = 'Edit';
localizedStrings['Done'] = 'Done';
localizedStrings['Theme:'] = 'Theme:';
localizedStrings['Glass'] = 'Glass';
localizedStrings['Black Edge'] = 'Black Edge';
localizedStrings['Deckled Edge'] = 'Deckled Edge';
localizedStrings['Pegboard'] = 'Pegboard';
localizedStrings['Torn Edge'] = 'Torn Edge';
localizedStrings['Vintage Corners'] = 'Vintage Corners';
localizedStrings['Only play audio in Dashboard'] = 'Only play audio in Dashboard';
