var localizedStrings = new Array;

localizedStrings['Edit'] = '编辑';
localizedStrings['Done'] = '完成';
localizedStrings['Theme:'] = '主题：';
localizedStrings['Glass'] = '玻璃框';
localizedStrings['Black Edge'] = '黑边';
localizedStrings['Deckled Edge'] = '毛边';
localizedStrings['Pegboard'] = '小钉板';
localizedStrings['Torn Edge'] = '撕边';
localizedStrings['Vintage Corners'] = '老式相角';
localizedStrings['Only play audio in Dashboard'] = '仅在 Dashboard 中播放音频';
