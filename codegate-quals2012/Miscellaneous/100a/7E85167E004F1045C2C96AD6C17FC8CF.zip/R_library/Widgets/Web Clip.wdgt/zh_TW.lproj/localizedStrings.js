﻿
var localizedStrings = new Array;

localizedStrings['Edit'] = '編輯';
localizedStrings['Done'] = '完成';
localizedStrings['Theme:'] = '主題：';
localizedStrings['Glass'] = '玻璃';
localizedStrings['Black Edge'] = '黑色邊緣';
localizedStrings['Deckled Edge'] = '毛邊';
localizedStrings['Pegboard'] = '展示板';
localizedStrings['Torn Edge'] = '邊緣撕裂';
localizedStrings['Vintage Corners'] = '經典角框';
localizedStrings['Only play audio in Dashboard'] = '僅在 Dashboard 中播放音訊';
