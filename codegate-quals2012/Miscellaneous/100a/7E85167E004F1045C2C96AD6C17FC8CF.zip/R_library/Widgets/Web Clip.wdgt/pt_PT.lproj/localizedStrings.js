var localizedStrings = new Array;

localizedStrings['Edit'] = 'Editar';
localizedStrings['Done'] = 'Terminado';
localizedStrings['Theme:'] = 'Tema:';
localizedStrings['Glass'] = 'Vidro';
localizedStrings['Black Edge'] = 'Moldura preta';
localizedStrings['Deckled Edge'] = 'Moldura recortada';
localizedStrings['Pegboard'] = 'Pegboard';
localizedStrings['Torn Edge'] = 'Extremidade rasgada';
localizedStrings['Vintage Corners'] = 'Cantos envelhecidos';
localizedStrings['Only play audio in Dashboard'] = 'Só áudio no Dashboard';
