var localizedStrings = new Array;

localizedStrings['Edit'] = 'Édition';
localizedStrings['Done'] = 'Terminé';
localizedStrings['Theme:'] = 'Thème :';
localizedStrings['Glass'] = 'Vitré';
localizedStrings['Black Edge'] = 'Bord noir';
localizedStrings['Deckled Edge'] = 'Bord frangé';
localizedStrings['Pegboard'] = 'Panneau perforé';
localizedStrings['Torn Edge'] = 'Bords déchirés';
localizedStrings['Vintage Corners'] = 'Coins à l’ancienne';
localizedStrings['Only play audio in Dashboard'] = 'Ne lire que l\'audio dans Dashboard';
