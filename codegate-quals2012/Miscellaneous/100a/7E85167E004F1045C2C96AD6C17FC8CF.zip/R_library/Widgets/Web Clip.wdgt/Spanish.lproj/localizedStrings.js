var localizedStrings = new Array;

localizedStrings['Edit'] = 'Edición';
localizedStrings['Done'] = 'Salir';
localizedStrings['Theme:'] = 'Tema:';
localizedStrings['Glass'] = 'Cristal';
localizedStrings['Black Edge'] = 'Borde negro';
localizedStrings['Deckled Edge'] = 'Borde deshilachado';
localizedStrings['Pegboard'] = 'Tablero';
localizedStrings['Torn Edge'] = 'Borde rasgado';
localizedStrings['Vintage Corners'] = 'Esquinas clásicas';
localizedStrings['Only play audio in Dashboard'] = 'Reproducir audio sólo en Dashboard';
