var localizedStrings = new Array;

localizedStrings['Edit'] = 'Bearb.';
localizedStrings['Done'] = 'Fertig';
localizedStrings['Theme:'] = 'Thema:';
localizedStrings['Glass'] = 'Glas';
localizedStrings['Black Edge'] = 'Schwarzer Rand';
localizedStrings['Deckled Edge'] = 'Büttenrrand';
localizedStrings['Pegboard'] = 'Stecktafel';
localizedStrings['Torn Edge'] = 'Zerfetzte Kante';
localizedStrings['Vintage Corners'] = 'Ecken (altmodisch)';
localizedStrings['Only play audio in Dashboard'] = 'Ton nur im Dashboard abspielen';
