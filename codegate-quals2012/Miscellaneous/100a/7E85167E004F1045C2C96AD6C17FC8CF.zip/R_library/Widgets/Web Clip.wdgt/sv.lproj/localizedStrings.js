var localizedStrings = new Array;

localizedStrings['Edit'] = 'Redigera';
localizedStrings['Done'] = 'Klar';
localizedStrings['Theme:'] = 'Tema:';
localizedStrings['Glass'] = 'Glas';
localizedStrings['Black Edge'] = 'Svart kant';
localizedStrings['Deckled Edge'] = 'Oskuren kant';
localizedStrings['Pegboard'] = 'Anslagstavla';
localizedStrings['Torn Edge'] = 'Riven kant';
localizedStrings['Vintage Corners'] = 'Gammaldags hörn';
localizedStrings['Only play audio in Dashboard'] = 'Spela bara ljud i Dashboard';
