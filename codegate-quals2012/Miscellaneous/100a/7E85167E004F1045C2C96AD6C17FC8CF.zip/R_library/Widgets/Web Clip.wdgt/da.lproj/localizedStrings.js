var localizedStrings = new Array;

localizedStrings['Edit'] = 'Rediger';
localizedStrings['Done'] = 'OK';
localizedStrings['Theme:'] = 'Tema:';
localizedStrings['Glass'] = 'Forvrængning';
localizedStrings['Black Edge'] = 'Sort kant';
localizedStrings['Deckled Edge'] = 'Bøtterand';
localizedStrings['Pegboard'] = 'Hultavle';
localizedStrings['Torn Edge'] = 'Revet kant';
localizedStrings['Vintage Corners'] = 'Gammeldags hjørner';
localizedStrings['Only play audio in Dashboard'] = 'Afspil kun lyd i Dashboard';
