﻿

var localizedStrings = new Array;
localizedStrings['Edit'] = 'Rediger';
localizedStrings['Done'] = 'Ferdig';
localizedStrings['Theme:'] = 'Tema:';
localizedStrings['Glass'] = 'Glass';
localizedStrings['Black Edge'] = 'Svart kant';
localizedStrings['Deckled Edge'] = 'Kant med dekkel';
localizedStrings['Pegboard'] = 'Pinnebrett';
localizedStrings['Torn Edge'] = 'Revet kant';
localizedStrings['Vintage Corners'] = 'Gammeldagse hjørner';
localizedStrings['Only play audio in Dashboard'] = 'Spill kun lyd i Dashboard';

