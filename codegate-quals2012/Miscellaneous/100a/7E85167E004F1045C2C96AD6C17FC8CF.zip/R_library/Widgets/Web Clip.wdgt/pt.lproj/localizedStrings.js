var localizedStrings = new Array;

localizedStrings['Edit'] = 'Editar';
localizedStrings['Done'] = 'OK';
localizedStrings['Theme:'] = 'Tema:';
localizedStrings['Glass'] = 'Vidro';
localizedStrings['Black Edge'] = 'Borda Preta';
localizedStrings['Deckled Edge'] = 'Borda de Molde';
localizedStrings['Pegboard'] = 'Tabuleiro';
localizedStrings['Torn Edge'] = 'Borda Desgast.';
localizedStrings['Vintage Corners'] = 'Cantos Clássicos';
localizedStrings['Only play audio in Dashboard'] = 'Somente reproduzir áudio no Dashboard';
