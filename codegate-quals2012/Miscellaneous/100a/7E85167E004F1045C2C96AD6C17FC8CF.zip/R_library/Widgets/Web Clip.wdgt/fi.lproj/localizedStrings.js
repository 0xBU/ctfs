
var localizedStrings = new Array;
localizedStrings['Edit'] = 'Muokkaa';
localizedStrings['Done'] = 'Valmis';
localizedStrings['Theme:'] = 'Teema:';
localizedStrings['Glass'] = 'Lasi';
localizedStrings['Black Edge'] = 'Musta reuna';
localizedStrings['Deckled Edge'] = 'Epätasainen reuna';
localizedStrings['Pegboard'] = 'Reikälevy';
localizedStrings['Torn Edge'] = 'Revitty reuna';
localizedStrings['Vintage Corners'] = 'Vanhat kulmat';
localizedStrings['Only play audio in Dashboard'] = 'Toista ääni vain Dashboardissa';

