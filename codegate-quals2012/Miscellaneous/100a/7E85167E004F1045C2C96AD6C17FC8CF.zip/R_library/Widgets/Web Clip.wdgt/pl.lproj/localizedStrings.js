var localizedStrings = new Array;

localizedStrings['Edit'] = 'Edycja';
localizedStrings['Done'] = 'Gotowe';
localizedStrings['Theme:'] = 'Motyw: ';
localizedStrings['Glass'] = 'Szklany';
localizedStrings['Black Edge'] = 'Czarna krawędź';
localizedStrings['Deckled Edge'] = 'Postrzępiona krawędź';
localizedStrings['Pegboard'] = 'Plansza';
localizedStrings['Torn Edge'] = 'Naddarte krawędzie';
localizedStrings['Vintage Corners'] = 'Stare narożniki';
localizedStrings['Only play audio in Dashboard'] = 'Audio odtwarzaj tylko w Dashboard';
