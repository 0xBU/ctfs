var localizedStrings = new Array;

localizedStrings['Edit'] = '編集';
localizedStrings['Done'] = '完了';
localizedStrings['Theme:'] = 'テーマ：';
localizedStrings['Glass'] = 'ガラス';
localizedStrings['Black Edge'] = 'ブラックエッジ';
localizedStrings['Deckled Edge'] = 'デッケルドエッジ';
localizedStrings['Pegboard'] = 'ペグボード';
localizedStrings['Torn Edge'] = 'トーンエッジ';
localizedStrings['Vintage Corners'] = 'ビンテージコーナー';
localizedStrings['Only play audio in Dashboard'] = 'Dashboard の表示時にのみ音声を出す';
