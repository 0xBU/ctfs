var localizedStrings = new Array;

localizedStrings['No song.'] = 'No Song';
localizedStrings['iTunes not running.'] = 'iTunes is not open';
localizedStrings['Done'] = 'Done';
localizedStrings['Checking iTunes status'] = 'Checking iTunes status';
localizedStrings['Select Playlist:'] = 'Select Playlist:';
