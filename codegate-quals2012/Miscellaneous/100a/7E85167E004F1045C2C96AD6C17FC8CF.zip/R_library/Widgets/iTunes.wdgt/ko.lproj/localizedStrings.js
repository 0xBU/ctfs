var localizedStrings = new Array;

localizedStrings['No song.'] = '노래 없음';
localizedStrings['iTunes not running.'] = 'iTunes가 열려 있지 않음';
localizedStrings['Done'] = '완료';
localizedStrings['Checking iTunes status'] = 'iTunes 상태 확인 중';
localizedStrings['Select Playlist:'] = '재생 목록 선택:';
