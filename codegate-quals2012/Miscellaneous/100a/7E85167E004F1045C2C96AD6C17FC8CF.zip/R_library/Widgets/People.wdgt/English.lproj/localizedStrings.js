var localizedStrings = new Array;

localizedStrings['White Pages'] = 'People';
localizedStrings['No Results'] = 'No Results Found.';
localizedStrings['Searching'] = 'Searching';
localizedStrings['Try a more specific search'] = 'Try a more specific search';
localizedStrings[' Miles'] = ' Miles'; // note the extra space character
localizedStrings['Search'] = 'Search';
localizedStrings['First Name'] = 'First Name';
localizedStrings['Last Name'] = 'Last Name';
localizedStrings['of'] = 'of';
localizedStrings[' items'] = ' items';
localizedStrings['Done'] = 'Done';

localizedStrings['City, State'] = 'City, State';
localizedStrings['or ZIP Code:'] = 'or ZIP Code:';
localizedStrings['City, State or ZIP Code'] = 'City, State or ZIP Code';
localizedStrings['Items per page:'] = 'Items per page:';
localizedStrings['Search within:'] = 'Search within:';

localizedStrings['Network unavailable.'] = 'Network unavailable.';
localizedStrings['Data unavailable.'] = 'Data unavailable.';
localizedStrings['Add %@ to AddressBook.'] = 'Add %@ to AddressBook.';
