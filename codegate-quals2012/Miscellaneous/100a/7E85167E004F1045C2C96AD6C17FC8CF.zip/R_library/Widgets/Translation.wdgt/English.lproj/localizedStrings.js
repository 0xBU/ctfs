var localizedStrings = new Array;

localizedStrings['Translate from'] = 'Translate from';
localizedStrings['To'] = 'To';
localizedStrings['Data unavailable.'] = 'Data unavailable.';
localizedStrings['Network unavailable.'] = 'Network unavailable.';
localizedStrings['Done'] = 'Done';
localizedStrings['Translating'] = 'Translating';


localizedStrings['Chinese (Simplified)'] = 'Chinese (Simplified)';
localizedStrings['Chinese (Traditional)'] = 'Chinese (Traditional)';
localizedStrings['Dutch'] = 'Dutch';
localizedStrings['English'] = 'English';
localizedStrings['French'] = 'French';
localizedStrings['Greek'] = 'Greek';
localizedStrings['German'] = 'German';
localizedStrings['Italian'] = 'Italian';
localizedStrings['Japanese'] = 'Japanese';
localizedStrings['Korean'] = 'Korean';
localizedStrings['Portuguese'] = 'Portuguese';
localizedStrings['Russian'] = 'Russian';
localizedStrings['Spanish'] = 'Spanish';

