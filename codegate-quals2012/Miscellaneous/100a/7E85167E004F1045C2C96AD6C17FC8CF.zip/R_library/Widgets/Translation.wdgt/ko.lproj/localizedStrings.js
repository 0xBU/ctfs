var localizedStrings = new Array;

localizedStrings['Translate from'] = '번역 원본';
localizedStrings['To'] = '결과';
localizedStrings['Data unavailable.'] = '데이터를 사용할 수 없습니다.';
localizedStrings['Network unavailable.'] = '네트워크를 사용할 수 없습니다.';
localizedStrings['Done'] = '완료';
localizedStrings['Translating'] = '번역하기';


localizedStrings['Chinese (Simplified)'] = '중국어(간체)';
localizedStrings['Chinese (Traditional)'] = '중국어(번체)';
localizedStrings['Dutch'] = '네덜란드어';
localizedStrings['English'] = '영어';
localizedStrings['French'] = '프랑스어';
localizedStrings['Greek'] = '그리스어';
localizedStrings['German'] = '독일어';
localizedStrings['Italian'] = '이탈리아어';
localizedStrings['Japanese'] = '일본어';
localizedStrings['Korean'] = '한국어';
localizedStrings['Portuguese'] = '포루투갈어';
localizedStrings['Russian'] = '러시아어';
localizedStrings['Spanish'] = '스페인어';

