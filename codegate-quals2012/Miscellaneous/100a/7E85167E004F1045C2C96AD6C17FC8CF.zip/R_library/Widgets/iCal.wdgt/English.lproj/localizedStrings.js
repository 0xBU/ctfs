var localizedStrings = new Array();

/*
Some (currently all) of these localized strings are not for display, but instead are for
localization of the ALT tags for HTML elements such as IMG (ie, images for buttons); the ALT
tags are used by VoiceOver to speak the names of the items.  Therefore, they should be localized
only if there exists a suitable speech synthesizer for the language being localized.
*/

localizedStrings['Previous Month Button']  = 'Previous Month Button';
localizedStrings['Next Month Button'] = 'Next Month Button';
localizedStrings['No upcoming events'] = 'No upcoming events';
localizedStrings['There are no upcoming events in iCal today.'] = 'There are no upcoming events in iCal today.';
localizedStrings['Add events'] = 'Add events';
