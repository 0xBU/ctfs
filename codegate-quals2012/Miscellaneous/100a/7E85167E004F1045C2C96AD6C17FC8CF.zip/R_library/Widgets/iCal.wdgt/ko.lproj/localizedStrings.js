
var localizedStrings = new Array();

localizedStrings['Previous Month Button']   = '이전 달 단추';
localizedStrings['Next Month Button']  = '다음 달 단추';
localizedStrings['No upcoming events']  = '예정된 이벤트 없음';
localizedStrings['There are no upcoming events in iCal today.']  = '오늘 iCal에 예정된 이벤트가 없습니다.';
localizedStrings['Add events']  = '이벤트 추가';
