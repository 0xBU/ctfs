var localizedStrings = new Array;

localizedStrings['Name'] = '이름';
localizedStrings['No Matching Cards'] = '일치하는 카드 없음';

localizedStrings['@1 of @2'] = '@1/@2';
localizedStrings['@1 found'] = '@1개가 발견됨';

localizedStrings['Address Book Search'] = '주소록 검색';

localizedStrings['AIMInstant'] = '@1(AIM)';
localizedStrings['JabberInstant'] = '@1(Jabber)';
localizedStrings['MSNInstant'] = '@1(MSN)';
localizedStrings['YahooInstant'] = '@1(Yahoo)';
localizedStrings['ICQInstant'] = '@1(ICQ)';
