var localizedStrings = new Array;

localizedStrings['Name'] = 'Name';
localizedStrings['No Matching Cards'] = 'No Matching Cards';

localizedStrings['@1 of @2'] = '@1 of @2';
localizedStrings['@1 found'] = '@1 found';

localizedStrings['Address Book Search'] = 'Address Book Search';

localizedStrings['AIMInstant'] = '@1 (AIM)';
localizedStrings['JabberInstant'] = '@1 (Jabber)';
localizedStrings['MSNInstant'] = '@1 (MSN)';
localizedStrings['YahooInstant'] = '@1 (Yahoo)';
localizedStrings['ICQInstant'] = '@1 (ICQ)';
