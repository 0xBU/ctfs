var localizedStrings = new Array;

localizedStrings['Phone Book'] = 'Business';
localizedStrings['Choose or Enter a Category'] = 'Choose or Enter a Category';
localizedStrings['NoResults'] = 'No Results Found.';
localizedStrings['Searching'] = 'Searching';
localizedStrings['Validating'] = 'Validating';
localizedStrings['No cities found'] = 'No cities found';
localizedStrings['Try a more specific search'] = 'Try a more specific search';
localizedStrings[' Miles'] = ' Miles'; // note the extra space character
localizedStrings['Search'] = 'Search';
localizedStrings['Business Name or Category'] = 'Business Name or Category';
localizedStrings['of'] = 'of';
localizedStrings[' items'] = ' items';
localizedStrings['Done'] = 'Done';

localizedStrings['City, State'] = 'City, State';
localizedStrings['or ZIP Code:'] = 'or ZIP Code:';
localizedStrings['Specify City, State or ZIP Code:'] = 'Specify: City, State';
localizedStrings['Items per page:'] = 'Items per page:';
localizedStrings['Search within:'] = 'Search within:';

localizedStrings['Network unavailable.'] = 'Network unavailable.';
localizedStrings['Data unavailable.'] = 'Data unavailable.';
localizedStrings['Add %@ to AddressBook.'] = 'Add %@ to AddressBook.';
