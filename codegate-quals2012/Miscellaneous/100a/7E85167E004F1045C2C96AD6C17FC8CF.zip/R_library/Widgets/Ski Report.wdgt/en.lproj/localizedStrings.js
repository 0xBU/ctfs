var localizedStrings = new Array;

localizedStrings["Done"] = "Done";
localizedStrings["Validating"] = "Validating";
localizedStrings["ziplabel"] = "Ski Resort:";
localizedStrings["unitlabel"] = "Degrees:";

localizedStrings["new"] = "new";
localizedStrings["base"] = "base";
localizedStrings["trails"] = "trails";

localizedStrings["corn"] = "corn";
localizedStrings["wet packed"] = "wet packed";
localizedStrings["wet granular"] = "wet granular";
localizedStrings["wet"] = "wet";
localizedStrings["variable"] = "variable";
localizedStrings["powder"] = "powder";
localizedStrings["granular"] = "granular";
localizedStrings["groomed"] = "groomed";
localizedStrings["icy"] = "icy";
localizedStrings["patchy"] = "patchy";
localizedStrings["good"] = "good";
localizedStrings["packed powder"] = "packed powder";
localizedStrings["hard packed"] = "hard packed";
localizedStrings["machine made"] = "machine made";
localizedStrings["spring"] = "spring";
localizedStrings["obstacles"] = "obstacles";
localizedStrings["skiers packed"] = "skiers packed";
localizedStrings["thin cover"] = "thin cover";
localizedStrings["wind blown"] = "wind blown";
localizedStrings["n/a"] = "n/a";

localizedStrings["Try a more specific search"] = "Try a more specific search";
localizedStrings["No resorts found"] = "No resorts found";


localizedStrings["closed"] = "CLOSED";
localizedStrings["unavailable"] = "Resort conditions unavailable.";
