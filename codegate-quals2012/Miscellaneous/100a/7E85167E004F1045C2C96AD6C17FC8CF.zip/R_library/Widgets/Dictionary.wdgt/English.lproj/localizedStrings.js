var localizedStrings = new Object();

/*
Localization chooses two dictionaries that are used by default, and a label for each.
Currently it uses dictionary name to specify a dictionary but it might be changed to either
bundle identifier or path to the dictionary bundle.
*/

localizedStrings['DictionaryName0'] = 'The New Oxford American Dictionary';
localizedStrings['DictionaryLabel0'] = 'Dictionary';

localizedStrings['DictionaryName1'] = 'The Oxford American Writer\'s Thesaurus';
localizedStrings['DictionaryLabel1'] = 'Thesaurus';

localizedStrings['"%@" could not be found.'] = '&#8220;%@&#8221; could not be found.';

localizedStrings['Done'] = 'Done';	// done button

// Font size preference
localizedStrings['Small']  = 'Small';
localizedStrings['Medium'] = 'Medium';
localizedStrings['Large']  = 'Large';
localizedStrings['Font size:'] = 'Font size:';
