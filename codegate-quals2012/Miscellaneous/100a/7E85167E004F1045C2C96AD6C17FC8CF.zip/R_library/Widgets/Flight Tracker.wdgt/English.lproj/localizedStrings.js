var localizedStrings = new Array;

localizedStrings['StartInstructions'] = 'Track your flight by airline or city';
localizedStrings['Getting flight information'] = 'Getting flight information';
localizedStrings['Searching for Flights'] = 'Searching for flights';
localizedStrings['Airline:'] = 'Airline:';
localizedStrings['Airline:'] = 'Airline:';
localizedStrings['Flight No:'] = 'Flight #:';
localizedStrings['Depart City:'] = 'Depart City:';
localizedStrings['Arrive City:'] = 'Arrive City:';

// if you are in a metric locale change 'MerasurementSystem' to the string 'Metric' 
// (this does not appear in the UI so do not localize to another language)
localizedStrings['MerasurementSystem'] = 'English';	// Must be either 'English' or 'Metric'
localizedStrings['SpeedUnits'] = 'MPH';				// if you are in a metric locale change this to 'KPH' or similar
localizedStrings['DistanceUnits'] = 'FEET';			// if you are in a metric locale change this to 'METERS' or similar

localizedStrings['Scheduled'] = 'Scheduled';
localizedStrings['Enroute'] = 'Enroute';
localizedStrings['Landed'] = 'Landed';
localizedStrings['Cancelled'] = 'Cancelled';
localizedStrings['Flight Landed'] = 'Flight landed';
localizedStrings['Approximate Flight Path'] = 'Approximate flight path';

// multileg strings

localizedStrings['Leg'] = 'Leg';
localizedStrings['Legs'] = 'Legs';
localizedStrings['Stop'] = 'Stop';
localizedStrings['Nonstop'] = 'Nonstop';
localizedStrings['City'] = 'City';
localizedStrings['Cities'] = 'Cities';
localizedStrings['ChangePlanes'] = 'Change planes';
localizedStrings['Via'] = 'Via';
localizedStrings['Stopped'] = 'Stopped';
localizedStrings['Stopover'] = 'Stopover';

// flight status strings
localizedStrings['FlightShort'] = 'Flight';
localizedStrings['Dpt'] = 'Dpt';
localizedStrings['Arv'] = 'Arv';
localizedStrings['A'] = 'A';
localizedStrings['D'] = 'D';
localizedStrings['DepartingShort'] = 'Departing';
localizedStrings['ArrivingShort'] = 'Arriving';
localizedStrings['Terminal'] = 'Term';
localizedStrings['Gate'] = 'Gate';


localizedStrings['On Time'] = 'On time';
localizedStrings['Delayed'] = 'Delayed';
localizedStrings['Day'] = 'Day';
localizedStrings['Hr'] = 'Hr';
localizedStrings['Mins'] = 'Mins';
localizedStrings['Min'] = 'Min';
localizedStrings['Minutes'] = 'Minutes';
localizedStrings['Late'] = 'Late';
localizedStrings['Early'] = 'Early';

localizedStrings['DayLowerCase'] = 'day';
localizedStrings['HrLowerCase'] = 'hr';
localizedStrings['MinsLowerCase'] = 'mins';
localizedStrings['MinutesLowerCase'] = 'minutes';

localizedStrings['Airline'] = 'Airline';
localizedStrings['Flight No'] = 'Flight No';
localizedStrings['Status'] = 'Status';
localizedStrings['Departs '] = 'Departs '; // note extra space character
localizedStrings['Arrives '] = 'Arrives '; // note extra space character

localizedStrings['Find Flights'] = 'Find Flights';
localizedStrings['Track Flight'] = 'Track Flight';
localizedStrings['Done'] = 'Done';

localizedStrings['Airports:'] = 'Airports:';
localizedStrings['Show Airlines from:'] = 'Show airlines from:';
localizedStrings['Africa'] = 'Africa';
localizedStrings['Asia'] = 'Asia';
localizedStrings['AustraliaAndOceania'] = 'Australia and Oceania';
localizedStrings['Europe'] = 'Europe';
localizedStrings['NorthAmerica'] = 'North America';
localizedStrings['SouthAmerica'] = 'South America';

localizedStrings['All'] = 'All';
localizedStrings['All Airlines'] = 'All Airlines';
localizedStrings['--Popular Airlines--'] = '--Popular Airlines--';
localizedStrings['--Other Airlines--'] = '--Other Airlines--';

// bundle names

localizedStrings['FlightTracker'] = 'FlightTracker';

// Error strings
localizedStrings['ErrorSystemUnavailable'] = 'Data unavailable.';
localizedStrings['ErrorNoInternetConnection'] = 'Network unavailable.';
localizedStrings['ErrorNoServer'] = 'Server unavailable.';
localizedStrings['ErrorFlightRulesViolation'] = 'Flight information unavailable.';
localizedStrings['ErrorNothingFound'] = 'No flights found.';
localizedStrings['NoFlightInfoAvailable'] = 'Flight information unavailable.';
localizedStrings['ErrorInvalidEntity'] = 'Unknown parameters.';
localizedStrings['ErrorInvalidSearchParams'] = 'Invalid search request. Please adjust your search parameters and try again.';
localizedStrings['PlaneLocationNotProvided'] = 'Airplane location not provided';
