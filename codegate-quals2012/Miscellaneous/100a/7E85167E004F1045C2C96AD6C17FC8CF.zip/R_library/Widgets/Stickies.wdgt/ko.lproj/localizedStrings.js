
var localizedStrings = new Array();

localizedStrings['Paper Color:']  = '용지 색상:';
localizedStrings['Font:']  = '서체:';
localizedStrings['Done']  = '완료';
localizedStrings['Auto']  = '자동';

var localizedFonts = new Array('AppleGothic','AppleMyungjo');

localizedFonts['AppleGothic']  = 'AppleGothic 일반체';
localizedFonts['AppleMyungjo']  = 'AppleMyungjo 일반체';

