#!/usr/bin/python

from elgamal import Elgamal
from client import SimpleClient
from os import urandom

#################################################################################################

# convert string to hex
def text2hex(text):
   temp = ''
   for i in text:
      temp += hex(ord(i)).replace('0x','')
   return '0x' + temp

# convert hex to string
def hex2text(hextext):
   temp = ''
   hextext = hextext.replace('0x','')
   for i in range(len(hextext)/2):
      tempchar = ''
      tempchar = hextext[(i*2)] + hextext[(i*2)+1]
      tempchar = '0x' + tempchar
      temp += chr(int(tempchar, 16))
   return temp

def getrandom(n):
   """ get random integer of n bytes size """
   return sum([ord(c)*256**i for i,c in enumerate(urandom(n))])

#################################################################################################

# create tcp client object
connection = SimpleClient('133.7.10.42', 31337)

# connect to server
connection.makeConnection()

# send key request
connection.sendCmd("Requesting Key")

# receive server public key
pubkeyserver = int(connection.getResults(), 16)

# create crypto object
crypto = Elgamal(getrandom(128))

# get public key
pubkey = crypto.getpubkey()

connection.makeConnection()
#send public key to server
connection.sendCmd("Public Key:" + hex(pubkey).replace('L',''))

# generate session key
crypto.generatesessionkey(pubkeyserver)

generatenewkey = False

while 1:
   #check if a new key has to be created
   if generatenewkey:
      #generate new private key
      crypto.setnewprivkey(getrandom(128))

      # get public key
      pubkey = crypto.getpubkey()

      connection.makeConnection()

      #send public key to server
      connection.sendCmd("Public Key:" + hex(pubkey).replace('L',''))

      # generate session key
      crypto.generatesessionkey(pubkeyserver)  

   cipher = raw_input("Enter text for transmission: ")

   #split text to 128byte blocks
   for i in range((len(cipher) // 128) + 1):

      #check if text part is empty
      if len(cipher[(i * 128):((i+1)*128)]) > 0:

         tempcipher = text2hex(cipher[(i * 128):((i+1)*128)])

         # encrypt
         tempcipher = crypto.encrypt(int(tempcipher, 16))

         connection.makeConnection()
         connection.sendCmd(hex(tempcipher).replace('L',''))
      else:
         break

   generatenewkey = True
   print "Message sent"
