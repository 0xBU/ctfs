#!/usr/bin/python
  
#a simple TCP client

from socket import *

BUFSIZE = 1024

class SimpleClient:
   def __init__(self, host, port):
      self.__HOST = host
      self.__PORT = port
      self.__ADDR = (self.__HOST,self.__PORT)
      self.__sock = None
  
   def makeConnection(self):
      self.__sock = socket( AF_INET,SOCK_STREAM)
      self.__sock.connect(self.__ADDR)
  
   def sendCmd(self, cmd):
      self.__sock.send(cmd)
  
   def getResults(self):
      data = self.__sock.recv(BUFSIZE)
      return data
